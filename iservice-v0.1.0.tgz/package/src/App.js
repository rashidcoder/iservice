import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css'; 
// The following line is not needed for react-toastify v3, only for v2.2.1
//import 'react-toastify/dist/ReactToastify.min.css';
 
class App extends Component {
 
 
  render() {
    return (
      <div className="App"> 
        <div className="App-header">
          <img src={logo} className="App-logo" alt="logo" />
          <h2>Welcome to React</h2>
        </div> 
      </div>
    );
  }
  
}

export default App;
