import PouchDB from 'pouchdb';
const dbName = 'iservice';
const adapter = "idb";
const passw = "%2!ab_oo(1"

class Database {


    async createDatabase() {
        var db = new PouchDB(dbName);
        // var db = new PouchDB('http://localhost:5984/kittens');
        return db;
    }

}